%Syeda Kubra Fatima
%code to resize image and save in bmp format
img=imread('peppers.png');
imshow(img);
reimg=imresize(img,1.5);
imshow(reimg);
imwrite(reimg, 'C:\Users\Hp-pc\Documents\MATLAB\pepperss.bmp');