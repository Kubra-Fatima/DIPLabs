
% Author name: Syeda Kubra Fatima
img= imread('pout.tif');   %loading image
subplot(1,3,1);             %creating subplot
imshow(img);            % showing the subplotted image
colormap winter         %giving effect to the image
