% Done by Syeda Kubra Fatima

img= imread('peppers.png');     %loading image
gr=img(:,:,2);          %separating green channel
imshow(gr);
rd=img(:,:,1);          %separating red channel
imshow(rd);
bl=img(:,:,3);          %separating blue channel
imshow(bl);