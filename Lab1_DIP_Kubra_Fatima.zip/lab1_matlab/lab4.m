% Syeda Kubra Fatima

img2=imread('pout.tif');
imagesc(img2);
colorbar
colormap summer
