"""
Author: Syeda Kubra Fatima
"""

import matplotlib.pyplot as plt
import matplotlib.image as im
from PIL import Image
from resizeimage import resizeimage


#task1
img=im.imread('moon.jpg');
plt.subplot(121); #1x2 grid with image in first column
plt.imshow(img);

plt.subplot(122);  #1x2 grid with image in second column
plt.imshow(img);


#task2

img_cha=img.copy();

r=img_cha[:,:,0];
g=img_cha[:,:,1];
b=img_cha[:,:,2];

plt.imshow(r);
plt.imshow(g);
plt.imshow(b);

##task3

#resize image with respect to the original image size
re_img= cv2.resize(img, (0,0), fx=0.75, fy=0.75)
cv2.imwrite('re_moon.bmp',re_img)
cv2.imshow('img', re_img)
